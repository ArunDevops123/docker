#!/bin/sh
filename="one.json"
ostype=$(grep -Po '"os_type": *\K"[^"]*"' $filename | tr -d '"')
echo "$ostype"
sleep 2
docker-compose -f $ostype.yml down
