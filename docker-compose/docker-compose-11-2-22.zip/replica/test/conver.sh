#!/bin/sh
rm -rf .env
filename="one.json"
cat  $filename | tr -d '\n' |
  grep -o '"[A-Za-z_][A-Za-z_0-9]\+"\s*:\s*\("[^"]\+"\|[0-9\.]\+\|true\|false\|null\)' |
  sed 's/"\(.*\)"\s*:\s*"\?\([^"]\+\)"\?/\1="\2"/'  | tr -d '"' >> .env