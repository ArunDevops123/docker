
filename="one.json"
ostype=$(grep -Po '"os_type": *\K"[^"]*"' $filename | tr -d '"')
echo "$ostype"

port=$(awk -v FS="custom_port=" 'NF>1{print $2}' .env | sed 's/,/ /g')

echo $port 

arr=($port)

echo "${arr[0]}"

sed -i 's/- "3000:.*/- "3000:'${arr[0]}'"/g' $ostype.yml
sed -i 's/- "3001:.*/- "3001:'${arr[1]}'"/g' $ostype.yml
sed -i 's/- "3002:.*/- "3002:'${arr[2]}'"/g' $ostype.yml
sed -i 's/- "3003:.*/- "3003:'${arr[3]}'"/g' $ostype.yml

sed -i 's/- "3004:.*/- "3004:'${arr[0]}'"/g' $ostype.yml
sed -i 's/- "3005:.*/- "3005:'${arr[1]}'"/g' $ostype.yml
sed -i 's/- "3006:.*/- "3006:'${arr[2]}'"/g' $ostype.yml
sed -i 's/- "3007:.*/- "3007:'${arr[3]}'"/g' $ostype.yml

sed -i 's/- "3008:.*/- "3008:'${arr[0]}'"/g' $ostype.yml
sed -i 's/- "3009:.*/- "3009:'${arr[1]}'"/g' $ostype.yml
sed -i 's/- "3010:.*/- "3010:'${arr[2]}'"/g' $ostype.yml
sed -i 's/- "3011:.*/- "3011:'${arr[3]}'"/g' $ostype.yml

sed -i 's/- "3012:.*/- "3012:'${arr[0]}'"/g' $ostype.yml
sed -i 's/- "3013:.*/- "3013:'${arr[1]}'"/g' $ostype.yml
sed -i 's/- "3014:.*/- "3014:'${arr[2]}'"/g' $ostype.yml
sed -i 's/- "3015:.*/- "3015:'${arr[3]}'"/g' $ostype.yml


